const { default: makeWASocket, useMultiFileAuthState, DisconnectReason, fetchLatestBaileysVersion, makeCacheableSignalKeyStore } = require('@whiskeysockets/baileys');
const pino = require('pino');
const axios = require('axios');
const QRCode = require('qrcode');
const express = require('express');
const cors = require('cors');
const { Server } = require('socket.io');
const http = require('http');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

const WEBHOOK_URL = process.env.WEBHOOK_URL || 'https://jtotljjdyhxjbbsnpuml.supabase.co/functions/v1/whatsapp-webhook';
const BOT_WHATSAPP_NUMBER = process.env.BOT_WHATSAPP_NUMBER;
const PORT = process.env.PORT || 8080;
const AUTH_DIR = process.env.RAILWAY_VOLUME_MOUNT_PATH || './auth_info';

console.log(`📂 Auth directory: ${AUTH_DIR}`);

if (!fs.existsSync(AUTH_DIR)) {
    fs.mkdirSync(AUTH_DIR, { recursive: true });
}

let sock;
let currentQR = null;
let connectionStatus = 'disconnected'; // disconnected, qr_ready, connecting, connected
const processedMessages = new Set();

// Express + Socket.io setup
const app = express();
const server = http.createServer(app);
const io = new Server(server, {
    cors: {
        origin: "*", // In production, specify your frontend URL
        methods: ["GET", "POST"]
    }
});

app.use(cors());
app.use(express.json());

// ============================================
// API ENDPOINTS FOR FRONTEND
// ============================================

/**
 * GET /api/status
 * Check bot connection status
 */
app.get('/api/status', (req, res) => {
    res.json({
        status: connectionStatus,
        connected: sock?.user ? true : false,
        user: sock?.user?.id || null,
        phoneNumber: sock?.user ? sock.user.id.split(':')[0] : null,
        hasAuth: fs.existsSync(AUTH_DIR) && fs.readdirSync(AUTH_DIR).length > 0,
        timestamp: new Date().toISOString()
    });
});

/**
 * GET /api/qr
 * Get current QR code as base64 image
 */
app.get('/api/qr', async (req, res) => {
    if (!currentQR) {
        return res.status(404).json({ 
            error: 'No QR code available',
            message: 'Bot is either connected or not generating QR. Check /api/status'
        });
    }

    try {
        // Convert QR string to base64 PNG image
        const qrImage = await QRCode.toDataURL(currentQR);
        
        res.json({
            qr: qrImage, // base64 PNG
            expiresIn: 20, // seconds
            status: 'qr_ready',
            message: 'Scan this QR code with WhatsApp'
        });
    } catch (error) {
        res.status(500).json({ error: 'Failed to generate QR image' });
    }
});

/**
 * POST /api/logout
 * Logout and disconnect WhatsApp
 */
app.post('/api/logout', async (req, res) => {
    try {
        if (sock) {
            await sock.logout();
        }
        
        // Delete auth files
        if (fs.existsSync(AUTH_DIR)) {
            fs.readdirSync(AUTH_DIR).forEach(file => {
                fs.unlinkSync(path.join(AUTH_DIR, file));
            });
        }
        
        connectionStatus = 'disconnected';
        currentQR = null;
        
        // Notify all connected frontends
        io.emit('status', { status: 'disconnected' });
        
        res.json({ 
            success: true, 
            message: 'Logged out successfully. Reconnecting...'
        });
        
        // Restart connection to generate new QR
        setTimeout(() => connectToWhatsApp(), 2000);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

/**
 * POST /api/reconnect
 * Force reconnection (useful if stuck)
 */
app.post('/api/reconnect', async (req, res) => {
    try {
        if (sock) {
            sock.end();
        }
        
        connectionStatus = 'connecting';
        
        res.json({ 
            success: true, 
            message: 'Reconnecting...'
        });
        
        setTimeout(() => connectToWhatsApp(), 1000);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Health check
app.get('/health', (req, res) => {
    res.json({
        status: 'running',
        connection: connectionStatus,
        connected: sock?.user ? true : false,
        timestamp: new Date().toISOString()
    });
});

// ============================================
// WEBSOCKET FOR REAL-TIME UPDATES
// ============================================

io.on('connection', (socket) => {
    console.log('🔌 Frontend connected:', socket.id);
    
    // Send current status immediately
    socket.emit('status', { 
        status: connectionStatus,
        connected: sock?.user ? true : false,
        phoneNumber: sock?.user ? sock.user.id.split(':')[0] : null
    });
    
    // If QR is available, send it
    if (currentQR && connectionStatus === 'qr_ready') {
        QRCode.toDataURL(currentQR).then(qrImage => {
            socket.emit('qr', { qr: qrImage });
        });
    }
    
    socket.on('disconnect', () => {
        console.log('🔌 Frontend disconnected:', socket.id);
    });
});

// ============================================
// WHATSAPP BOT LOGIC
// ============================================

async function sendToWebhook(fromPhone, message, messageId) {
    try {
        const cleanPhone = fromPhone.replace(/[^0-9]/g, '');
        
        const response = await axios.post(WEBHOOK_URL, {
            from: `whatsapp:+${cleanPhone}`,
            to: `whatsapp:${BOT_WHATSAPP_NUMBER}`,
            body: message,
            messageSid: messageId,
            numMedia: 0,
            timestamp: new Date().toISOString()
        }, {
            headers: { 'Content-Type': 'application/json' },
            timeout: 30000
        });

        return response.data;
    } catch (error) {
        console.error('❌ Webhook error:', error.message);
        throw error;
    }
}

async function sendWhatsAppMessage(jid, text) {
    try {
        if (!sock) return;
        await sock.sendMessage(jid, { text });
        console.log(`✅ Sent message to ${jid}`);
    } catch (error) {
        console.error(`❌ Failed to send message:`, error.message);
    }
}

async function connectToWhatsApp() {
    try {
        console.log('\n🔄 Initiating WhatsApp connection...');
        
        connectionStatus = 'connecting';
        io.emit('status', { status: 'connecting' });
        
        const { state, saveCreds } = await useMultiFileAuthState(AUTH_DIR);
        const { version, isLatest } = await fetchLatestBaileysVersion();
        
        console.log(`🔧 Using WA version v${version.join('.')}, isLatest: ${isLatest}`);

        sock = makeWASocket({
            version,
            logger: pino({ level: 'silent' }),
            auth: {
                creds: state.creds,
                keys: makeCacheableSignalKeyStore(state.keys, pino({ level: 'silent' }))
            },
            browser: ['Hospital Bot', 'Chrome', '1.0.0'],
            markOnlineOnConnect: true,
            syncFullHistory: false,
            printQRInTerminal: false,
            getMessage: async () => ({ conversation: '' })
        });

        sock.ev.on('connection.update', async (update) => {
            const { connection, lastDisconnect, qr } = update;

            if (qr) {
                console.log('📱 QR Code generated');
                currentQR = qr;
                connectionStatus = 'qr_ready';
                
                // Convert to base64 image
                const qrImage = await QRCode.toDataURL(qr);
                
                // Broadcast to all connected frontends
                io.emit('qr', { qr: qrImage, expiresIn: 20 });
                io.emit('status', { status: 'qr_ready' });
            }

            if (connection === 'open') {
                console.log('\n✅ WHATSAPP CONNECTED!');
                connectionStatus = 'connected';
                currentQR = null;
                
                const phoneNumber = sock.user ? sock.user.id.split(':')[0] : null;
                
                // Broadcast to all frontends
                io.emit('status', { 
                    status: 'connected',
                    phoneNumber: phoneNumber,
                    connected: true
                });
                
                io.emit('connected', { 
                    success: true,
                    phoneNumber: phoneNumber,
                    message: 'WhatsApp connected successfully!'
                });
            }

            if (connection === 'close') {
                const statusCode = lastDisconnect?.error?.output?.statusCode;
                const reason = lastDisconnect?.error?.output?.payload?.error || 'unknown';
                
                console.log(`❌ Connection closed. StatusCode: ${statusCode}, Reason: ${reason}`);
                
                connectionStatus = 'disconnected';
                currentQR = null;
                
                io.emit('status', { 
                    status: 'disconnected',
                    reason: reason
                });
                
                const shouldReconnect = statusCode !== DisconnectReason.loggedOut;
                
                if (shouldReconnect) {
                    console.log('🔄 Reconnecting in 5s...');
                    setTimeout(() => connectToWhatsApp(), 5000);
                } else {
                    console.log('🔴 Logged out');
                    io.emit('logged_out', { 
                        message: 'WhatsApp logged out. Please scan QR again.'
                    });
                }
            }
        });

        sock.ev.on('creds.update', saveCreds);

        sock.ev.on('messages.upsert', async ({ messages, type }) => {
            if (type !== 'notify') return;

            for (const msg of messages) {
                try {
                    if (!msg.message || msg.key.fromMe) continue;

                    const messageId = msg.key.id;
                    
                    if (processedMessages.has(messageId)) continue;
                    processedMessages.add(messageId);
                    
                    if (processedMessages.size > 1000) {
                        const arr = Array.from(processedMessages);
                        processedMessages.clear();
                        arr.slice(-500).forEach(id => processedMessages.add(id));
                    }

                    const remoteJid = msg.key.remoteJid;
                    let phone = '';
                    
                    if (msg.key.senderPn) {
                        phone = msg.key.senderPn.split('@')[0].replace(/[^0-9]/g, '');
                    } else if (msg.key.participant) {
                        phone = msg.key.participant.split('@')[0].replace(/[^0-9]/g, '');
                    } else if (remoteJid) {
                        phone = remoteJid.split('@')[0].replace(/[^0-9]/g, '');
                    }
                    
                    let messageText = '';
                    if (msg.message.conversation) {
                        messageText = msg.message.conversation;
                    } else if (msg.message.extendedTextMessage?.text) {
                        messageText = msg.message.extendedTextMessage.text;
                    } else if (msg.message.imageMessage?.caption) {
                        messageText = msg.message.imageMessage.caption;
                    } else {
                        continue;
                    }

                    console.log(`\n📨 New message from +${phone}: "${messageText}"`);
                    
                    // Notify frontend of new message
                    io.emit('message_received', {
                        from: phone,
                        message: messageText,
                        timestamp: new Date().toISOString()
                    });

                    const webhookResponse = await sendToWebhook(phone, messageText, messageId);

                    if (webhookResponse?.response) {
                        await sendWhatsAppMessage(remoteJid, webhookResponse.response);
                        
                        // Notify frontend of message sent
                        io.emit('message_sent', {
                            to: phone,
                            message: webhookResponse.response,
                            timestamp: new Date().toISOString()
                        });
                    }

                } catch (error) {
                    console.error('❌ Error processing message:', error.message);
                }
            }
        });

    } catch (error) {
        console.error('❌ Fatal connection error:', error);
        connectionStatus = 'error';
        io.emit('status', { status: 'error', error: error.message });
        
        setTimeout(() => connectToWhatsApp(), 10000);
    }
}

// ============================================
// START SERVER
// ============================================

server.listen(PORT, () => {
    console.log(`🚀 Bot server running on port ${PORT}`);
    console.log(`📍 API: http://localhost:${PORT}`);
    console.log(`📍 Status: http://localhost:${PORT}/api/status`);
    console.log(`📍 QR Code: http://localhost:${PORT}/api/qr`);
    console.log(`🔌 WebSocket: ws://localhost:${PORT}`);
    console.log('');
});

console.log('\n🚀 Starting Hospital WhatsApp Bot...');
console.log(`🌐 Webhook: ${WEBHOOK_URL}`);
console.log(`📂 Auth: ${AUTH_DIR}`);
console.log(`📱 Bot Number: ${BOT_WHATSAPP_NUMBER || 'Not set'}\n`);

connectToWhatsApp();

// Graceful shutdown
process.on('SIGTERM', () => {
    console.log('\n🛑 SIGTERM - shutting down');
    server.close(() => process.exit(0));
});

process.on('SIGINT', () => {
    console.log('\n🛑 SIGINT - shutting down');
    server.close(() => process.exit(0));
});
