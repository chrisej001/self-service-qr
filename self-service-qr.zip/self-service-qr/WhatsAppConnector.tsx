import React, { useState, useEffect } from 'react';
import { io } from 'socket.io-client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Loader2, CheckCircle, XCircle, Smartphone, RefreshCw } from 'lucide-react';

// Configure this to your bot server URL
const BOT_SERVER_URL = process.env.NEXT_PUBLIC_BOT_SERVER_URL || 'http://localhost:8080';

export function WhatsAppConnector() {
  const [status, setStatus] = useState('loading'); // loading, disconnected, qr_ready, connected
  const [qrCode, setQrCode] = useState(null);
  const [phoneNumber, setPhoneNumber] = useState(null);
  const [error, setError] = useState(null);
  const [socket, setSocket] = useState(null);

  useEffect(() => {
    // Check initial status
    fetch(`${BOT_SERVER_URL}/api/status`)
      .then(res => res.json())
      .then(data => {
        setStatus(data.status);
        if (data.phoneNumber) {
          setPhoneNumber(data.phoneNumber);
        }
      })
      .catch(err => {
        setError('Failed to connect to bot server');
        setStatus('error');
      });

    // Connect to WebSocket for real-time updates
    const newSocket = io(BOT_SERVER_URL);
    setSocket(newSocket);

    newSocket.on('connect', () => {
      console.log('Connected to bot server');
    });

    newSocket.on('status', (data) => {
      console.log('Status update:', data);
      setStatus(data.status);
      if (data.phoneNumber) {
        setPhoneNumber(data.phoneNumber);
      }
      if (data.status === 'connected') {
        setQrCode(null); // Clear QR when connected
      }
    });

    newSocket.on('qr', (data) => {
      console.log('QR code received');
      setQrCode(data.qr);
      setStatus('qr_ready');
    });

    newSocket.on('connected', (data) => {
      console.log('WhatsApp connected!', data);
      setPhoneNumber(data.phoneNumber);
      setQrCode(null);
      setStatus('connected');
    });

    newSocket.on('logged_out', (data) => {
      console.log('Logged out:', data);
      setStatus('disconnected');
      setQrCode(null);
      setPhoneNumber(null);
    });

    newSocket.on('disconnect', () => {
      console.log('Disconnected from server');
    });

    return () => {
      newSocket.close();
    };
  }, []);

  const handleLogout = async () => {
    try {
      const response = await fetch(`${BOT_SERVER_URL}/api/logout`, {
        method: 'POST'
      });
      const data = await response.json();
      
      if (data.success) {
        setStatus('disconnected');
        setQrCode(null);
        setPhoneNumber(null);
      }
    } catch (err) {
      setError('Failed to logout');
    }
  };

  const handleReconnect = async () => {
    try {
      const response = await fetch(`${BOT_SERVER_URL}/api/reconnect`, {
        method: 'POST'
      });
      
      setStatus('connecting');
      setError(null);
    } catch (err) {
      setError('Failed to reconnect');
    }
  };

  const refreshQR = async () => {
    try {
      const response = await fetch(`${BOT_SERVER_URL}/api/qr`);
      const data = await response.json();
      
      if (data.qr) {
        setQrCode(data.qr);
        setStatus('qr_ready');
      }
    } catch (err) {
      // QR might not be ready yet
      handleReconnect();
    }
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Smartphone className="h-6 w-6" />
          WhatsApp Connection
        </CardTitle>
        <CardDescription>
          Connect your WhatsApp to start receiving patient messages
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        
        {/* Status Badge */}
        <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
          <div className="flex items-center gap-2">
            <div className={`h-3 w-3 rounded-full ${
              status === 'connected' ? 'bg-green-500' :
              status === 'qr_ready' ? 'bg-yellow-500' :
              status === 'connecting' ? 'bg-blue-500' :
              'bg-gray-400'
            }`} />
            <span className="font-medium">
              {status === 'connected' ? 'Connected' :
               status === 'qr_ready' ? 'Scan QR Code' :
               status === 'connecting' ? 'Connecting...' :
               status === 'disconnected' ? 'Disconnected' :
               'Loading...'}
            </span>
          </div>
          
          {phoneNumber && (
            <span className="text-sm text-muted-foreground">
              +{phoneNumber}
            </span>
          )}
        </div>

        {/* Error Message */}
        {error && (
          <Alert variant="destructive">
            <XCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {/* Connected State */}
        {status === 'connected' && (
          <div className="space-y-4">
            <Alert>
              <CheckCircle className="h-4 w-4 text-green-600" />
              <AlertDescription className="text-green-800">
                Your WhatsApp is connected and ready to receive messages!
              </AlertDescription>
            </Alert>
            
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">
                Phone Number: <span className="font-mono">+{phoneNumber}</span>
              </p>
              <p className="text-sm text-muted-foreground">
                Status: Active and receiving messages
              </p>
            </div>

            <Button variant="outline" onClick={handleLogout} className="w-full">
              Disconnect WhatsApp
            </Button>
          </div>
        )}

        {/* QR Code State */}
        {status === 'qr_ready' && qrCode && (
          <div className="space-y-4">
            <Alert>
              <AlertDescription>
                Scan this QR code with your WhatsApp to connect:
                <ol className="mt-2 ml-4 list-decimal text-sm space-y-1">
                  <li>Open WhatsApp on your phone</li>
                  <li>Go to Settings → Linked Devices</li>
                  <li>Tap "Link a Device"</li>
                  <li>Scan the QR code below</li>
                </ol>
              </AlertDescription>
            </Alert>

            <div className="flex flex-col items-center space-y-4">
              <div className="border-4 border-slate-200 rounded-lg p-4 bg-white">
                <img 
                  src={qrCode} 
                  alt="QR Code" 
                  className="w-64 h-64"
                />
              </div>
              
              <p className="text-sm text-muted-foreground text-center">
                QR code expires in 20 seconds. Click refresh if it expires.
              </p>

              <Button 
                variant="outline" 
                onClick={refreshQR}
                className="w-full"
              >
                <RefreshCw className="mr-2 h-4 w-4" />
                Refresh QR Code
              </Button>
            </div>
          </div>
        )}

        {/* Connecting State */}
        {status === 'connecting' && (
          <div className="flex flex-col items-center space-y-4 py-8">
            <Loader2 className="h-12 w-12 animate-spin text-blue-600" />
            <p className="text-sm text-muted-foreground">
              Connecting to WhatsApp...
            </p>
          </div>
        )}

        {/* Disconnected State */}
        {status === 'disconnected' && !qrCode && (
          <div className="space-y-4">
            <Alert variant="destructive">
              <XCircle className="h-4 w-4" />
              <AlertDescription>
                WhatsApp is not connected. Click below to generate a QR code.
              </AlertDescription>
            </Alert>

            <Button onClick={handleReconnect} className="w-full">
              Connect WhatsApp
            </Button>
          </div>
        )}

        {/* Loading State */}
        {status === 'loading' && (
          <div className="flex flex-col items-center space-y-4 py-8">
            <Loader2 className="h-12 w-12 animate-spin text-slate-600" />
            <p className="text-sm text-muted-foreground">
              Loading connection status...
            </p>
          </div>
        )}

      </CardContent>
    </Card>
  );
}
