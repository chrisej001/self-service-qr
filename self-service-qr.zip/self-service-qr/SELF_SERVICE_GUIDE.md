# 🎯 Self-Service WhatsApp QR Setup

## Overview

This system allows doctors to connect their own WhatsApp numbers directly from your dashboard **without any technical help**.

---

## 🏗️ How It Works

```
1. Doctor logs into dashboard
2. Clicks "Connect WhatsApp"
3. QR code appears on screen (via WebSocket)
4. Doctor scans with phone
5. ✅ Connected! Bot starts immediately
```

**No CLI, no server access, no technical knowledge needed!**

---

## 📦 What You Need

### **Backend Changes:**
- ✅ Updated bot server with QR API
- ✅ WebSocket support for real-time updates
- ✅ REST API endpoints

### **Frontend Changes:**
- ✅ React component to display QR
- ✅ WebSocket client for real-time connection
- ✅ Connection status UI

---

## 🚀 Setup Instructions

### **Step 1: Update Backend (Bot Server)**

Replace your `index.js` with `backend-with-qr-api.js`

**Additional Dependencies:**
```bash
npm install socket.io qrcode cors
```

**New package.json:**
```json
{
  "dependencies": {
    "@whiskeysockets/baileys": "^6.7.8",
    "axios": "^1.6.0",
    "dotenv": "^16.0.3",
    "express": "^4.18.2",
    "pino": "^8.16.0",
    "qrcode": "^1.5.3",
    "qrcode-terminal": "^0.12.0",
    "socket.io": "^4.6.0",
    "cors": "^2.8.5"
  }
}
```

**Deploy:**
```bash
# Railway
git add .
git commit -m "Add QR API support"
git push

# Or manually
npm install
npm start
```

---

### **Step 2: Add Frontend Component (Lovable)**

Copy `WhatsAppConnector.tsx` to your Lovable project.

**Install Dependencies:**
```bash
npm install socket.io-client lucide-react
```

**Add to Doctor's Dashboard:**
```tsx
import { WhatsAppConnector } from '@/components/WhatsAppConnector';

export function DoctorSettings() {
  return (
    <div className="container mx-auto p-6">
      <h1 className="text-3xl font-bold mb-6">Settings</h1>
      
      {/* WhatsApp Connection Section */}
      <WhatsAppConnector />
      
      {/* Other settings... */}
    </div>
  );
}
```

**Configure Bot Server URL:**

In your `.env`:
```env
NEXT_PUBLIC_BOT_SERVER_URL=https://your-bot-server.railway.app
```

---

### **Step 3: Deploy One Bot Per Doctor**

Each doctor needs their own bot instance.

#### **Option A: Railway (Recommended for <10 doctors)**

For each doctor:
1. Create Railway project: `doctor-smith-bot`
2. Connect GitHub repo
3. Set environment variables:
   ```
   BOT_WHATSAPP_NUMBER=+234XXXXXXXXX
   WEBHOOK_URL=https://your-supabase.co/functions/v1/whatsapp-webhook
   PORT=8080
   ```
4. Deploy
5. Get Railway URL: `https://doctor-smith-bot.railway.app`
6. Update doctor's record in database:
   ```sql
   UPDATE hospitals 
   SET bot_server_url = 'https://doctor-smith-bot.railway.app'
   WHERE id = 'doctor-smith-id';
   ```

#### **Option B: Single VPS with Nginx (10+ doctors)**

Run multiple bots on one server with different ports:

**docker-compose.yml:**
```yaml
version: '3'
services:
  bot-doctor1:
    build: .
    environment:
      - BOT_WHATSAPP_NUMBER=+2349042967356
      - PORT=8081
    ports:
      - "8081:8081"
    volumes:
      - ./auth_doctor1:/app/auth_info

  bot-doctor2:
    build: .
    environment:
      - BOT_WHATSAPP_NUMBER=+2348012345678
      - PORT=8082
    ports:
      - "8082:8082"
    volumes:
      - ./auth_doctor2:/app/auth_info
```

**Nginx config:**
```nginx
# Doctor 1
location /api/doctor1/ {
    proxy_pass http://localhost:8081/;
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection "upgrade";
}

# Doctor 2
location /api/doctor2/ {
    proxy_pass http://localhost:8082/;
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection "upgrade";
}
```

---

## 🎨 Frontend Flow

### **Doctor Experience:**

1. **Disconnected State:**
   ```
   ❌ WhatsApp is not connected
   [Connect WhatsApp Button]
   ```

2. **Clicks Button → QR Appears:**
   ```
   📱 Scan this QR code:
   [QR CODE IMAGE]
   Instructions:
   1. Open WhatsApp
   2. Go to Settings → Linked Devices
   3. Scan this code
   ```

3. **Scans QR:**
   ```
   🔄 Connecting...
   ```

4. **Connected:**
   ```
   ✅ WhatsApp Connected!
   Phone: +2349042967356
   Status: Active
   [Disconnect Button]
   ```

---

## 🔌 API Endpoints

### **GET /api/status**
Check connection status
```json
{
  "status": "connected",
  "connected": true,
  "phoneNumber": "2349042967356",
  "timestamp": "2024-01-01T00:00:00Z"
}
```

### **GET /api/qr**
Get current QR code as base64 image
```json
{
  "qr": "data:image/png;base64,iVBORw0KGgoAAAANS...",
  "expiresIn": 20,
  "status": "qr_ready"
}
```

### **POST /api/logout**
Disconnect WhatsApp
```json
{
  "success": true,
  "message": "Logged out successfully"
}
```

### **POST /api/reconnect**
Force reconnection
```json
{
  "success": true,
  "message": "Reconnecting..."
}
```

---

## 🔄 WebSocket Events

### **Client → Server:**
```javascript
// Connect
socket.connect();

// Get status
socket.on('status', (data) => {
  console.log(data); // { status: 'connected', phoneNumber: '234...' }
});

// Receive QR
socket.on('qr', (data) => {
  console.log(data); // { qr: 'data:image/png;base64,...' }
});

// Connection established
socket.on('connected', (data) => {
  console.log(data); // { success: true, phoneNumber: '234...' }
});
```

---

## 📊 Multi-Doctor Architecture

```
Frontend Dashboard (Lovable)
  ├─ Doctor 1 Settings Page
  │    └─ WhatsAppConnector (bot-server-1.railway.app)
  │         └─ Displays QR / Status for Doctor 1
  │
  ├─ Doctor 2 Settings Page
  │    └─ WhatsAppConnector (bot-server-2.railway.app)
  │         └─ Displays QR / Status for Doctor 2
  │
  └─ Doctor 3 Settings Page
       └─ WhatsAppConnector (bot-server-3.railway.app)
            └─ Displays QR / Status for Doctor 3

Backend:
  ├─ Bot Server 1 (Railway) - Doctor 1's WhatsApp
  ├─ Bot Server 2 (Railway) - Doctor 2's WhatsApp
  └─ Bot Server 3 (Railway) - Doctor 3's WhatsApp

Database:
  hospitals table:
    - Doctor 1: bot_server_url = 'https://bot-1.railway.app'
    - Doctor 2: bot_server_url = 'https://bot-2.railway.app'
    - Doctor 3: bot_server_url = 'https://bot-3.railway.app'
```

---

## 🎯 Dynamic Bot Server URLs

**In your frontend component:**

```tsx
export function WhatsAppConnector({ doctorId }: { doctorId: string }) {
  const [botServerUrl, setBotServerUrl] = useState<string | null>(null);

  useEffect(() => {
    // Fetch doctor's bot server URL from your API
    fetch(`/api/doctors/${doctorId}/bot-server`)
      .then(res => res.json())
      .then(data => setBotServerUrl(data.bot_server_url));
  }, [doctorId]);

  if (!botServerUrl) return <div>Loading...</div>;

  // Use dynamic URL
  const socket = io(botServerUrl);
  // ...
}
```

---

## 💡 Scaling Strategy

### **Small Practice (1-5 doctors):**
- Deploy separate Railway project per doctor
- Cost: $5/doctor/month = $25/month max

### **Medium Practice (5-20 doctors):**
- Single VPS ($20/month)
- Docker Compose with multiple containers
- Nginx reverse proxy

### **Large Practice (20+ doctors):**
- Kubernetes cluster
- Auto-scaling based on usage
- Load balancing

---

## 🔐 Security Considerations

1. **Authentication:**
   - Only logged-in doctors can access their QR endpoint
   - Verify doctor ID matches bot owner

2. **Rate Limiting:**
   - Limit QR generation requests (1 per 30 seconds)
   - Prevent QR spam

3. **CORS:**
   - Only allow your frontend domain
   - Block unauthorized origins

4. **WebSocket Auth:**
   - Verify JWT token on socket connection
   - Only allow doctor to connect to their own bot

---

## 📝 Database Schema Addition

Add bot server URL to hospitals table:

```sql
ALTER TABLE hospitals 
ADD COLUMN bot_server_url TEXT;

-- Example
UPDATE hospitals 
SET bot_server_url = 'https://doctor-smith-bot.railway.app'
WHERE id = 'doctor-smith-id';
```

---

## ✅ Complete Setup Checklist

### Backend:
- [ ] Install new dependencies (socket.io, qrcode, cors)
- [ ] Replace index.js with backend-with-qr-api.js
- [ ] Deploy to Railway/VPS
- [ ] Test API endpoints (/api/status, /api/qr)
- [ ] Test WebSocket connection

### Frontend:
- [ ] Install socket.io-client
- [ ] Add WhatsAppConnector component
- [ ] Configure bot server URL
- [ ] Add to doctor settings page
- [ ] Test QR code display
- [ ] Test real-time connection updates

### Database:
- [ ] Add bot_server_url column
- [ ] Update each doctor's record with their bot URL

### Per Doctor:
- [ ] Deploy bot instance (Railway/Docker)
- [ ] Update database with bot URL
- [ ] Doctor logs in and clicks "Connect WhatsApp"
- [ ] Doctor scans QR code
- [ ] Verify connection works
- [ ] Test sending/receiving messages

---

## 🎉 Result

After setup, doctors can:
1. ✅ Log into dashboard
2. ✅ Click "Connect WhatsApp"
3. ✅ See QR code instantly
4. ✅ Scan with phone
5. ✅ Start receiving messages immediately
6. ✅ Disconnect/reconnect anytime

**No technical support needed!** 🚀

---

## 📞 Troubleshooting

### QR not appearing?
- Check bot server is running: `curl https://bot.railway.app/health`
- Check WebSocket connection in browser console
- Verify CORS is allowing your frontend domain

### Connection keeps dropping?
- Check Railway volume is configured
- Verify auth_info folder is persisting
- Check server logs for errors

### Multiple doctors see same QR?
- Each doctor MUST have separate bot instance
- Check bot_server_url is unique per doctor
- Verify frontend is using correct URL

---

**This is a production-ready, scalable solution!** 🎯
